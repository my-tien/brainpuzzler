# -*- coding: utf-8 -*-
"""
ELEKTRONN - Neural Network Toolkit
Copyright (c) 2015 Gregor Urban, Marius Killinger

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software for non-commercial purposes, including
the rights to use, copy, modify, merge, publish, distribute, the Software,
and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The Software shall neither be used as part or facilitating factor of military
applications, nor be used to develop or facilitate the development
of military applications.
The Software and derivative work is not used commercially.
The above copyright notice and this permission notice shall be included in
all copies and all derivative work of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

import sys
import time
import CNNData
import traindata
import numpy as np
import trainutils

from Net import introspection as intro
from Net.netcreation import createNet
from multiprocessing import Process
from matplotlib import pyplot as plt
from parallelisation import BackgroundProc
from skimage import io

class Trainer(object):
  """
  Object that manages Training of a CNN.

  Parameters
  ----------

  config: trainutils.ConfigObj
    Container for all configurations

  Examples
  --------

  All necessary configuration information is contained in cofig:

    >>> T = Trainer(config)
    >>> T.loadData()
    >>> T.createNet()
    >>> T.run() # The Training loop

  If the config options ``print_status`` and ``plot_on`` are set the CNN progress can be supervised.

  Control during iteration can be exercised by ctrl+c which evokes a commandline.
  There are various shortcuts displayed but in principle all attributes of the CNN can be accessed:

    >>> CNN MENU
    >> Debug_Run <<
    Shortcuts:
    'q' (leave interface),	    'abort' (saving params),
    'kill'(no saving),	    'save'/'load' (opt:filename),
    'sf'/' (show filters)',	    'smooth' (smooth filters),
    'sethist <int>',	    'setlr <float>',
    'setmom <float>' ,	    'params' print info,
    Change Training mode :('SGD','CG', 'RPROP', 'LBFGS')
    For EVERYTHING else enter your command in the command line
    >>> user@cnn: setlr 0.01 # Change learning rate of SGD
    >>> user@cnn: CG # Change Training mode CG (Optimizer will be compiled on demand)
    Changing Training mode...
    >>> user@cnn: self.config.savename # Access an attribute of ``trainerInstance``.
    # Inputs containing '(' or '=' will result in a print of the value
    'Debug_Run'
    >>> user@cnn: print cnn.getDropoutRates() # To see the return of function add 'print'
    [0.5, 0.5]
    >>> user@cnn: cnn.setOptimizerParams(CG={'max_step': 0.1}) # change CG-'max_step'
    >>> user@cnn: q # leave interface
    Continuing Training
    Compiling CG
      Compiling done - in 7.206 s!

  """
  def __init__(self, config=None):
    self.config      = config
    self.data        = None
    self.cnn         = None
    self.CG_timeline = []
    self.history     = []
    self.timeline    = []
    self.errors      = []
    self.param_vars  = []
    self.saved_raw_preview = False


  def reset(self):
    """
    Resets all history of NLLs etc and randomizes CNN weights, optimiser hyper-parameters are set to initial
    values from config
    """
    self.cnn.randomizeWeights()
    self.cnn.setOptimizerParams(self.config.SGD_params, self.config.CG_params,
                                self.config.RPROP_params, self.config.LBFGS_params,
                                self.config.weight_decay)
    self.cnn.CG_timeline = []
    self.history         = []
    self.timeline        = []
    self.errors          = []
    self.param_vars      = []


  def run(self):
    """
    Runs the Training loop until termination. Control during iteration can be exercised by ctrl+c which
    evokes a commandline. There are various shortcuts displayed but in principle all attributes of the
    CNN can be accessed:

    Examples
    --------

    Using the command line

      >>> CNN MENU
      >> Debug_Run <<
      Shortcuts:
      'q' (leave interface),	    'abort' (saving params),
      'kill'(no saving),	    'save'/'load' (opt:filename),
      'sf'/' (show filters)',	    'smooth' (smooth filters),
      'sethist <int>',	    'setlr <float>',
      'setmom <float>' ,	    'params' print info,
      Change Training mode :('SGD','CG', 'RPROP', 'LBFGS')
      For EVERYTHING else enter your command in the command line
      >>> user@cnn: setlr 0.01 # Change learning rate of SGD
      >>> user@cnn: CG # Change Training mode CG (Optimizer will be compiled on demand)
      Changing Training mode...
      >>> user@cnn: self.config.savename # Access an attribute of ``trainerInstance``.
      # Inputs containing '(' or '=' will result in a print of the value
      'Debug_Run'
      >>> user@cnn: print cnn.getDropoutRates() # To see the return of function add 'print'
      [0.5, 0.5]
      >>> user@cnn: cnn.setOptimizerParams(CG={'max_step': 0.1}) # change CG-'max_step'
      >>> user@cnn: q # leave interface
      Continuing Training
      Compiling CG
        Compiling done - in 7.206 s!
    """
    save_name   = self.config.save_name
    cnn         = self.cnn
    data        = self.data
    config      = self.config    
    t_passed    = 0
    t_per_train = 1
    t_pt        = 2
    t_pi        = 2
    last_save_t = 0
    save_time   = 1
    nll_ema     = 0.65
    user_termination = False
    plotting_proc = []
    
    pp_loss = 'MSE' if config.target=='regression' else 'NLL'
    pp_err  = 'std' if config.target=='regression' else '%%'

    # --------------------------------------------------------------------------------------------------------
    if config.background_processes:      
      bg_worker = BackgroundProc(data.getbatch, n_proc=2, target_kwargs=self.get_batch_kwargs)
    # --------------------------------------------------------------------------------------------------------
    try:
      t0 = time.time()
      for i in xrange(config.n_steps):
        try:
          if config.background_processes:
            batch = bg_worker.get()
          else:
            batch = data.getbatch(**self.get_batch_kwargs)
          
          if config.class_weights is not None:
            batch = batch + (config.class_weights,)
          if config.label_prop_thresh is not None:
            batch = batch + (config.label_prop_thresh,)
                                       
          #-----------------------------------------------------------------------------------------------------
          nll, nll_instance, param_vars, t_per_train = cnn.trainingStep(*batch, mode=config.training_mode) # Update step         
          #-----------------------------------------------------------------------------------------------------
          t_per_it = time.time() - t0
          t0 = time.time()
          
          if np.any(np.isnan(nll)) or np.allclose(nll, 0.0):
            print "The NN diverged badly!!!\
            You have the chane to inspect the last used examples and the internal state of pipeline in the\
            command line. The last presented training input data is `batch[0]` and the corresponding target `batch[1]`"
            raise KeyboardInterrupt
          
          nll_ema = 0.995*nll_ema + 0.005*nll  # EMA
          t_pt = 0.8*t_pt + 0.2*t_per_train  # EMA
          t_pi = 0.8*t_pi + 0.2*t_per_it     # EMA
          t_passed   += t_per_it
          batch_char = batch[1].mean()
          self.timeline.append([i, t_passed, nll_ema, nll, batch_char])
          self.param_vars.append(param_vars)
          if (t_passed-last_save_t)/3600 > 1: # every hour
            last_save_t = t_passed
            time_string = '-'+str(save_time)+'h'
            cnn.saveParameters(save_name+time_string+'.param', show=False)
            config.preview_kwargs['number'] = save_time
            if save_time%2==1 and (self.preview_data is not None): # only every 2 hours!
              self.previewSlice(**config.preview_kwargs)
              
            save_time += 1
  
          if i%1000==0: # update learning rate (exp. decay)
             cnn.setSGDLR(np.float32(cnn.SGD_LR.get_value()*config.LR_decay))
  
          if (i%config.history_freq[0]==0) and config.history_freq[0]!=0:
            self.CG_timeline = cnn.CG_timeline
            ### Training  & Valid Errors ###
            nll_after = cnn.get_loss(*batch)[0]
            nll_gain  = nll_after - nll
            train_nll, train_error = self.testModel('train')
            valid_nll, valid_error = self.testModel('valid')
            if config.target!='regression':
              train_error *= 100
              valid_error *= 100
  
            self.errors.append([i, t_passed, train_error, valid_error])
            self.history.append([i, t_passed, nll_ema, nll, train_nll, valid_nll,  nll_gain])
  
            ### Monitoring / Output ###
            #np.save('Backup/'+save_name+".DataHist",  np.array(self.data.HIST)) ### DEBUG
            cnn.saveParameters(save_name+'-LAST.param', show=False)
  
            if config.plot_on and i>30:
              [p.join() for p in plotting_proc] # join before new plottings are started
              plotting_proc = []
              p0 = Process(target=trainutils.plotInfo, args=(self.timeline, self.history,
                                                     self.CG_timeline, self.errors, save_name))
              plotting_proc.extend([p0])
              [p.start() for p in plotting_proc]
            else:
              trainutils.saveHist(self.timeline, self.history,self.CG_timeline, self.errors, save_name)
  
            if config.print_status:
              out = '%05i %sm=%.3f, train=%05.2f%s, valid=%05.2e%s, prev=%04.1f, NLLdiff=%+.1e, LR=%.5f, %.1f it/s, '\
              %(i, pp_loss, nll_ema, train_error, pp_err, valid_error, pp_err, batch_char*100, nll_gain,
                cnn.SGD_LR.get_value(), 1.0/t_pi)
              t = trainutils.pprinttime(t_passed)
              print out+t
  
        # User Interface #####################################################################################
        except KeyboardInterrupt:          
          out = '%05i %s=%.5f, NLL=%.4f, train=%.5f, valid=%.5f, train=%.3f%s, valid=%.3f%s,\n\
      LR=%.6f, MOM=%.6f, %.1f GPU-it/s, %.1f CPU-it/s, '\
          %(i, pp_loss, nll_ema, nll, train_nll, valid_nll, train_error, pp_err, valid_error, pp_err,
            cnn.SGD_LR.get_value(), cnn.SGD_momentum.get_value(),1.0/t_pt, 1.0/t_pi)
          
          t = trainutils.pprinttime(t_passed)
          print out+t
  
          # Like a command line, it must be here to access workspace variables
          trainutils.pprintmenu(save_name)
          while True:
            try:
              ret = trainutils.userInput(cnn, config.history_freq)
              plt.pause(0.001)
              if ret is None or ret=="":
                continue
              if ret=="abort":
                user_termination=True
                break
              elif ret=='kill':
                return
              elif ret in ['SGD', 'RPROP', 'CG', 'LBFGS']:
                config.training_mode = ret
              elif ret == 'q':
                print "Continuing Training"
                break
              elif ret=='sf':
                intro.plotFilters(cnn)
              else:
                if '(' in ret or '=' in ret: # execute statements and assignments
                  exec(ret)
                else: # print value of identifiers
                  exec('print '+ret)
  
            except:
              sys.excepthook(*sys.exc_info()) # show info on error
  
          if self.config.background_processes:
           bg_worker.reset()
  
        # End UI ###############################################################################################
        if (t_passed > config.max_runtime) or user_termination : # This is in the epoch/UI loop
          print 'Timeout or manual Termination'
          break
      # This is OUTSIDE the training loop i.e. the last block of the function ``run``
      self.cnn.saveParameters(save_name+"_end.param")
      trainutils.plotInfo(self.timeline, self.history, self.CG_timeline, self.errors, save_name)
      print 'End of Training'
      print '#'*60 + '\n' + '#'*60 + '\n'
      # -------------------end of run()---------------------------------------------------------------------------
    
    except:
      sys.excepthook(*sys.exc_info()) # show info on error
    finally:
      if config.background_processes:
        bg_worker.shutdown()


  def loadData(self):
    config      = self.config
    if self.config.mode!='vect-scalar' and self.config.data_class_name is None: # image training
      strided = ~np.any(config.MFP) and config.mode=='img-img'
      
      self.get_batch_kwargs =      dict(batch_size=config.batch_size,
                                   strided=strided,
                                   flip=config.flip_data,
                                   grey_augment_channels=config.grey_augment_channels,
                                   ret_info=config.lazy_labels,
                                   warp_on=config.warp_on,
                                   ignore_thresh=config.example_ignore_threshold)
      
      # the source is replaced in self.testModel to be valid
      self.get_batch_kwargs_test = dict(batch_size=config.monitor_batch_size,
                                   strided=strided,
                                   flip=config.flip_data,
                                   grey_augment_channels=config.grey_augment_channels,
                                   ret_info=config.lazy_labels,
                                   warp_on=False,
                                   ignore_thresh=config.example_ignore_threshold) # no warp    
    
      self.data   = CNNData.CNNData(config.patch_size,
                                config.dimensions.pred_stride,
                                config.dimensions.offset,
                                config.n_dim,
                                config.n_lab,
                                config.anisotropic_data,
                                config.mode,
                                config.zchxy_order,
                                config.border_mode,
                                config.upright_x)
  
      self.data.addDataFromFile(config.data_path,
                                config.label_path,
                                config.d_files,
                                config.l_files,
                                config.cube_prios,
                                config.valid_cubes)

      if self.config.preview_data_path is not None:
        data = trainutils.h5Load(self.config.preview_data_path)
        data = [d.astype(np.float32)/255 for d in data]
        self.preview_data = data
        
      else:
        self.preview_data = None
    
    else: # non-image training
      self.get_batch_kwargs      = dict(batch_size=config.batch_size)
      self.get_batch_kwargs.update(self.config.data_batch_kwargs)
      # the source is replaced in self.testModel to be valid
      self.get_batch_kwargs_test = dict(batch_size=config.monitor_batch_size)
      Data = getattr(traindata, self.config.data_class_name)
      self.data   = Data(**self.config.data_load_kwargs)                  

                              
  def createNet(self):
    """
    Creates CNN according to config
    """
    n_lab = self.data.n_lab
    if self.config.class_weights is not None:
      if self.config.target=='nll':
        assert len(self.config.class_weights) == n_lab,\
        "The number of class weights must equal the number of classes"
      
    if self.config.mode!='vect-scalar': # image training
      n_ch  = self.data.n_ch  
      self.cnn = createNet(self.config, self.config.patch_size, n_ch, n_lab, self.config.dimensions)
    else: # non-image training 
      n_ch = None     
      if self.config.rnn_layer_kwargs is not None:
        n_ch = self.data.n_taps # must be None if the data should be repeated
          
      self.cnn = createNet(self.config, self.data.example_shape, n_ch, n_lab, None)  


  def debugGetCNNBatch(self):
    """
    Executes ``getbatch`` but with un-strided labels and always returning info. The first batch example
    is plotted and the whole batch is returned for inspection.
    """
    if self.config.mode=='img-img':
      data, label, info1, info2 = self.data.getbatch(self.config.monitor_batch_size, source='train',
                                 strided=False,
                                 flip=self.config.flip_data,
                                 grey_augment_channels=self.config.grey_augment_channels,
                                 ret_info=True)
      if self.config.n_dim==2:
        CNNData.plotTrainingTarget(data[0,0], label[0], 1)
      else:
        i = int(self.config.dimensions.offset)
        CNNData.plotTrainingTarget(data[0,i,0], label[0,0], 1)
      print "Info1=",info1
      print "Info2=",info2
      plt.show()
      plt.savefig('debugGetCNNBatch.png', bbox_inches='tight')
  
      return data, label, info1, info2
    else:
      print "This funciton is only available for 'img-img' training mode"


  def testModel(self, data_source):
    """
    Computes NLL and error/accuracy on batch with ``monitor_batch_size``

    Parameters
    ----------

    data_source: string
        'train' or 'valid'

    Returns
    -------
    NLL, error:

    """
    if data_source=='valid':
      if not hasattr(self.data, 'valid_d') or not hasattr(self.data.valid_d, '__len__') or len(self.data.valid_d)==0:
        return np.nan, np.nan # 0, 0

    kwargs = dict(self.get_batch_kwargs_test) # copy because it is modified in next line!
    kwargs['source']=data_source   
    batch = self.data.getbatch(**kwargs)

    y_aux = []
    if self.config.class_weights is not None:
      y_aux.append(self.config.class_weights)
    if self.config.label_prop_thresh is not None:
      y_aux.append(self.config.label_prop_thresh)
                               
    rates = self.cnn.getDropoutRates()
    self.cnn.setDropoutRates([0.0,]*len(rates))
    n = len(batch[0])
    nll = 0
    error = 0
    for j in xrange(int(np.ceil(np.float(n)/self.config.batch_size))):
      d = batch[0][j*self.config.batch_size:(j+1)*self.config.batch_size] # data
      l = batch[1][j*self.config.batch_size:(j+1)*self.config.batch_size] # label
      if len(batch)==4:
        i1 = batch[2][j*self.config.batch_size:(j+1)*self.config.batch_size]
        i2 = batch[3][j*self.config.batch_size:(j+1)*self.config.batch_size]
        nl, er, pred =  self.cnn.get_error(d, l, i1, i2, *y_aux)
      else:
        nl, er, pred =  self.cnn.get_error(d, l, *y_aux)
      nll += nl*len(d)
      error += er*len(d)
    nll /= n
    error /= n
    self.cnn.setDropoutRates(rates) # restore old rates
    return nll, error
  
  
  def predictAndWrite(self, raw_img, number=0, export_class='all', block_name='', z_thick=5):
    """
    Predict and and save a slice as preview image
    
    Parameters
    ----------
    
    raw_img : np.ndarray
      raw data in the format (ch, x, y, z)
    number: int
      consecutive number for the save name (i.e. hours, iterations etc.)
    export_class: str or int
      'all' writes images of all classes, otherwise only the class with index ``export_class`` (int) is saved.
    block_name: str
      Name/number to distinguish different raw_imges
    """

    block_name = str(block_name)
    pred = self.cnn.predictDense(raw_img)
    
    z_sh = pred.shape[-1]
    pred = pred[:,:,:,(z_sh-z_thick)//2:(z_sh-z_thick)//2+z_thick]

    save_name = self.config.save_name
    for z in xrange(pred.shape[3]):
      if export_class=='all':
        for c in xrange(pred.shape[0]):
          io.imsave('%s-pred-%s-c%i-z%i-%ihrs.png'%(save_name, block_name, c, z, number), pred[c,:,:,z])
      else:
        c = int(export_class)
        io.imsave('%s-pred-%s-c%i-z%i-%ihrs.png'%(save_name, block_name, c, z, number), pred[c,:,:,z])

    if not self.saved_raw_preview: # only do once
      z_off = 0 if len(self.config.dimensions.offset)==2 else int(self.config.dimensions.offset[0])
      for z in xrange(pred.shape[3]):
        io.imsave('%s-raw-%s-z%i.png'%(save_name, block_name, z), raw_img[0,:,:,z+z_off])

    
  def previewSliceFromTrainData(self, cube_i=0, off=(0,0,0), sh=(10,400,400), number=0, export_class='all'):
    """
    Predict and and save a selected slice from the training data as preview
    
    Parameters
    ----------
    
    cube_i: int
      index of source cube in CNNData
    off: 3-tuple of int
      start index of slice to cut from cube (z,x,y)
    sh: 3-tuple of int
      shape of cube to cut (z,x,y)
    number: int
      consecutive number for the save name (i.e. hours, iterations etc.)
    export_class: str or int
      'all' writes images of all classes, otherwise only the class with index ``export_class`` (int) is saved.
    """
    if not self.config.mode=='img-img':
      print "This funciton is only available for 'img-img' training mode"
      return
      
    if self.cnn.n_dim==3:
      min_z = self.cnn.input_shape[1]
      if min_z > sh[0]:
        sh = list(sh)
        sh[0] = min_z

    raw_img = self.data.train_d[cube_i]
    raw_img = raw_img[off[0]:off[0]+sh[0],:,
                      off[1]:off[1]+sh[1],
                      off[1]:off[1]+sh[1]]

    raw_img = np.transpose(raw_img, (1,2,3,0)) # (z,ch,x,y) --> (ch,x,y,z)
    self.predictAndWrite(raw_img, number, export_class)
    self.saved_raw_preview = True


  def previewSlice(self, number=0, export_class='all', max_z_pred=5):
    """
    Predict and and save a data from a separtely loaded file as preview
    
    Parameters
    ----------
    
    number: int
      consecutive number for the save name (i.e. hours, iterations etc.)
    export_class: str or int
      'all' writes images of all classes, otherwise only the class with index ``export_class`` (int) is saved.
    max_z_pred: int
      approximate maximal number of z-slices to produce (depends on CNN architecture)
    """
    if not self.config.mode=='img-img':
      print "This funciton is only available for 'img-img' training mode"
      return

    assert self.preview_data is not None, "You must provide preview data in order to call this function"
    for example_no,raw_img in enumerate(self.preview_data): 
      z_sh = raw_img.shape[2]
      if self.cnn.n_dim==3:         
        strd_z = self.cnn.output_strides[0]
        out_z  = self.cnn.output_shape[2] * strd_z 
        min_z  = self.cnn.input_shape[1] + strd_z - 1
        z_thick = min_z if out_z > max_z_pred else min_z + strd_z*int(np.ceil(float(max_z_pred-out_z)/strd_z))
      else:
        z_thick = max_z_pred
      
      assert z_thick <= z_sh, "The preview slices are too small in z-direction for this CNN"
        
      raw_img = raw_img[None,:,:,(z_sh-z_thick)//2:(z_sh-z_thick)//2+z_thick]    
      self.predictAndWrite(raw_img, number, export_class, example_no, max_z_pred)
      
    self.saved_raw_preview = True