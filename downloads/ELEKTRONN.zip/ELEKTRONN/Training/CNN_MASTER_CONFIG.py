# -*- coding: utf-8 -*-
"""
ELEKTRONN - Neural Network Toolkit
Copyright (c) 2015 Gregor Urban, Marius Killinger

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software for non-commercial purposes, including
the rights to use, copy, modify, merge, publish, distribute, the Software,
and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The Software shall neither be used as part or facilitating factor of military
applications, nor be used to develop or facilitate the development
of military applications.
The Software and derivative work is not used commercially.
The above copyright notice and this permission notice shall be included in
all copies and all derivative work of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""
"""
CONFIGURATION FOR CNN-TRAINING
------------------------------

- In the comments values in [] denotes preferred/recommended settings
- Paths must have trailing '/'
- For isotropic CNNs (same input and filter size in all directions) the variable desired_input is scalar and
  filters & nof_filters are lists of scalars. For anisotropic CNNs all scalars are replaced by the
  lists of respective shapes.
"""

### Paths and General ###
save_path        = "~/CNN_Training/2D/" # (*) where to create the CNN directory. In this directory a new folder is created
save_name        = 'Debug'              # (*) with the save_name.
overwrite        = True                 # whether to delete/overwrite existing directory
plot_on          = True                 # [True]/False: whether to create plots of the errors etc.
print_status     = True                 # [True]/False: whether to print Training status to std.out
save_path += save_name+'/'
param_file       = None                 # string/None: optional parameter file to initialise weights from

### Data Basic ###
data_path        = '/'                 # (*) Path to data dir
label_path       = '/'                 # (*) Path to label dir
d_files          = []                  # (*) list of tuples of file name and filed name in h5 data set
l_files          = []                  # (*) list of tuples of file name and filed name in h5 data set
n_lab            = None                # (*) <int>/None: (None means auto detect, very slow, don't do this!)
mode             = 'img-img'           # combination of data and label types: 'img-img', 'img-scalar', vect-scalar'

### CNNData (image data) Options (those are ignored for mode 'vect-scalar') ###
cube_prios       = None                # List of sampling priorities for cubes or None, then: sampling ~ example_size
                                       # will be normalised internally
valid_cubes      = []                  # List of cube indices (from the file-lists) to use as validation data,
                                       # may be empty
example_ignore_threshold = 0.0         # If the fraction of negative labels in an example patch exceeds
                                       # this threshold this example is discarded
grey_augment_channels = [0]            # (*) list of <int> channel-indices to apply grey augmentation, use [] to disable.
                                       # It distorts the histogram of the raw images (darker, lighter, more/less contrast)
flip_data        = True                # [True]/False: whether to flip/rotate/mirror data randomly (augmentation)
anisotropic_data = True                # (*) <Bool>, if True 2D slices are only cut in z-direction, otherwise all 3 alignments are used
lazy_labels      = False               # ($) Special Training with lazy annotations
warp_on          = False               # <Bool>/<Float> (0,1)Warping augmentations (CPU-intense, use background processes!)
                                       #  If this is a float than warping is applied to this fraction of examples e.g. 0.5 --> every other example
border_mode	 = "crop"	                # Only applicable for *img-scalar*. If the CNN does not allow the original size of the images
                                       # the following options are available:
                                       #"strip": cut the images to the next smaller valid input size,
                                       # "0-pad" padd to the next bigger valid input with zeros,
                                       # "c-pad" padd to the next bigger input with the average value of the border,
                                       # "mirror" and "reject" which throws an exception.
zchxy_order      = False               # set to True if data is in (z, (ch,) x, y) order, otherwise (ch, x, y, z) is assume
upright_x        = False
preview_data_path = None
preview_kwargs = dict(export_class=1, max_z_pred=5) # specification of preview data


### Gereral Data options ###
background_processes = False           # whether to "pre-fetch" batches in separate background process
label_prop_thresh    = None

### Alternative / vect_scalar Data Options (these replace CNNData Options) ###
data_class_name      = None            # string, Name of Data Class in TrainData
data_load_kwargs     = dict()          # Arguments to init Data Class
data_batch_kwargs    = dict()          # Arguments for getbach method of Data Class (for training set only!)
                                       # The batch_size argument is added internally and needn't be specified here

### CNN Architecture ###
activation_func = 'tanh'               # string of list of strings: [tanh], abs, linear, sig, relu, single string or list with entry per layer
batch_size      = 1                    # (*) [1]/<int>  number of different slices used for one update step
dropout_rates   = []                   # (*) list of <float>(0,1)/float: "fail"-rates per layer or globally.
                                       # The last layer has always no dropout. If list, length must be total number of layers
# Note: the last layer is added automatically (with n_lab outputs)
# Conv layers
n_dim           = 2                    # (*) 2/3, for non image data (mode 'vect-scalar') this is ignored
desired_input   = 100                  # (*) <int> or <2/3-tuple> in (x,y)/(x,y,z)-order for anisotropic CNN
filters         = []                   # (*) list of <int>/[] or list of <2/3-tuples> in (x,y)/(x,y,z)-order
pool            = []                   # (*) list of <int>/[],
nof_filters     = []                   # (*) list of <int>/[]
pooling_mode     = 'max'
MFP             = []                   # (*) list of <int{0,1}>/False: whether to apply Max-Fragment-Pooling in this layer
# Other
rnn_layer_kwargs = None                # If in use: dict(n_hid=<int>,  activation_func='tanh', iterations=None/<int>)
MLP_layers      = []                   # (*) list of <int>: numbers of filters for fully connected layers after conv layers
target          = 'nll'                # 'nll' or 'regression'

### Optimisation Options ###
n_steps               = 10**12          # (*) number of update steps
max_runtime           = 24 * 3600      # (*)  maximal Training time in seconds (overrides n_steps)
history_freq          = [500]          # (*) create plots, print status and test model after x steps (must be list to be mutable)
monitor_batch_size    = 10              # (*) number of patches to test model on (valid and Training subset)

weight_decay          = False          # ($) [False]/<float>: L2-norm on weights, False is equal to 0.0
class_weights         = None           # None or list/array of float weights for the classes, will be normalised internally
training_mode         = 'SGD'          # [SGD]/CG/RPORP/LBFGS optimiser method for training

LR_decay              = 0.993          # (*) decay of SGD learning rate w.r.t to an interval of 1000 update steps

# SGD
SGD_params      = dict(LR=0.001, momentum=0.9)  # (*) initial learning rate and momentum

SSGD_params     = dict(LR=0.01, momentum=0.9, var_momentum=0.9, var_cuttoff=3.0)

# RPROP ($)
RPROP_params    = dict(penalty=0.35, gain=0.2, beta=0.7, initial_update_size=1e-4)
# CG ($)
CG_params       = dict(n_steps=4,       # update steps per same batch 3 <--> 6
                       alpha=0.35,      # termination criterion of line search, must be <= 0.35
                       beta=0.75,       # precision of line search,  imprecise 0.5 <--> 0.9 precise
                       max_step=0.02,   # similar to learning rate in SGD 0.1 <--> 0.001.
                       min_step=8e-5)

# LBFGS ($)
LBFGS_params    = dict(maxfun= 40,      # function evaluations
                       maxiter= 4,      # iterations
                       m= 10,           # maximum number of variable metric corrections
                       factr= 1e2,      # factor of machine precision as termination criterion (haha!)
                       pgtol= 1e-9,     # projected gradient tolerance
                       iprint= -1)      # set to 0 for direct printing of steps