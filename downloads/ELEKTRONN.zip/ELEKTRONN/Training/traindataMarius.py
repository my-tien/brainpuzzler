# -*- coding: utf-8 -*-
"""
Marius' Private Data Sets, Not for Release! 
"""
import numpy as np
import cPickle
import gc
import multiprocessing as mp
from sklearn import feature_extraction
from sklearn import decomposition

from TrainData import Data, BalancedData, QueueData

def loadStockData(path='/docs/entwicklung/data/features.pkl'):
  try:
    with open(path, 'r') as f: #trian_d, train_l, valid_d, valid_l, split1, split2
      trd, trl, td, tl = cPickle.load(f)
      dates= []
      for i in xrange(2):
        dates.append(cPickle.load(f))

      return StockData(trd, trl, td, tl, *dates)
  except ValueError:
     with open(path, 'r') as f: #trian_d, train_l, valid_d, valid_l, split1, split2
      l= []
      for i in xrange(6):
        l.append(cPickle.load(f))

      return StockData(*l)

class StockData(QueueData):
  """
  Load and prepare data
  """
  def __init__(self, train_d, train_l, valid_d, valid_l, split1=None, split2=None):
    self.train_d = train_d.astype('float32')
    self.train_l = train_l.astype('float32')
    self.valid_d  = valid_d.astype('float32')
    self.valid_l  = valid_l.astype('float32')
    self.split1  = split1 # Dates
    self.split2  = split2
    super(StockData, self).__init__()

  def __repr__(self):
    return "Stock Feature Data Set:\n\
    * Total number of training examples: %i and validing: %i\n\
    * Train data before %s, Test data after %s."\
    %(self._training_count, self.valid_d.shape[0], self.split1, self.split2)


  def save(self, path='/docs/entwicklung/data/features.pkl'):
    super(StockData, self).save(path)
    with open(path, 'a') as f:
      cPickle.dump(self.split1, f, protocol = 2)
      cPickle.dump(self.split2, f, protocol = 2)

  def labelize(self):
    def labelize(a, mode='avg', bins=None):
#      if mode=='avg':
#        bins=[-np.inf, -0.01, -0.005, 0.005, 0.01, np.inf]
#      elif mode =='max':
#        bins=[0, 0.005, 0.01, 0.02, 0.03, np.inf]
#      elif mode=='min':
#        bins=[-0, -0.005, -0.01, -0.02, -0.03, -np.inf]
#        bins.reverse()
      if mode=='avg':
        bins=[-np.inf, -0.008, 0.008, np.inf]
      else:
        #elif mode =='max':
        bins=[0, 0.001, 0.0015, np.inf]
        if mode=='min':
          bins.reverse()
          bins = map(lambda x: -x, bins)

      label = np.zeros_like(a, dtype='int16')
      for i in xrange(len(bins)-1):
        label[(bins[i] <= a) & (a < bins[i+1])] = i
      return label

    def _labelize_col(data):
      for i,(l,mode) in enumerate(zip(data.T, ['max', 'min', 'avg', 'max', 'min', 'avg'])):
        data.T[i] = labelize(l, mode)

      return data.astype('int16')

    self.train_l = _labelize_col(self.train_l)
    self.valid_l  = _labelize_col(self.valid_l)
    self.nlab = np.unique(self.train_l).size

  def selectlabels(self, ix):
    """ ix: list of coloums to keep"""
    self.train_l = self.train_l[:,ix]
    self.valid_l  = self.valid_l[:,ix]


##############################################################################################################
 
def _loadchunck(path, i):
  """Load data and discard it: this puts it into system cache, and it is faster than using mp.Queue =/"""
  #print 'PROCESS: Loading new chunck %i' %i
  d = np.load(path+'D'+str(i)+'.npy')
  d = None
  gc.collect()
  #print 'PROCESS: Done new chunck %i' %i
   
class CTRData(BalancedData):
  def __init__(self, path='/docs/entwicklung/data/CTR/', split_no=0, block=False):
    self._block = block
    avilable_sets = range(48)
    rng = np.random.RandomState(22031991+split_no)
    rng.shuffle(avilable_sets)
    i = avilable_sets.pop() 
    
    self.valid_d  = np.load(path+'D'+str(i)+'.npy') / 10
    self.valid_l = np.load(path+'L'+str(i)+'.npy')
    
    blocked = range(113,139) + range(50,76) + range(154,180)  # device_ip, site_domain, device_model 
    self._partial_ix = np.ones(316, dtype=np.bool)
    self._partial_ix[blocked] = False
    if self._block:
      self.valid_d = self.valid_d[:,self._partial_ix]
      
    self.avilable_sets = avilable_sets
    self.path = path    
    self.train_pos  = 0
    self.loadnewchunk() # This already contais call to: super(CTRData, self).__init__()

  def loadnewchunk(self):
    if hasattr(self, '_preload'):
      self._preload.join()
      print "Joined a preloader"
      
    i = self.avilable_sets[self.train_pos]
    self.train_d = None
    gc.collect()
    print 'Loading new chunck from: %s'%(self.path+'D'+str(i)+'.npy')
    self.train_d  = np.load(self.path+'D'+str(i)+'.npy')
    if self._block:
      self.train_d = self.train_d[:,self._partial_ix]
      
    self.train_l = np.load(self.path+'L'+str(i)+'.npy')
    self.train_pos = (self.train_pos+1)%47
    p = mp.Process( name='loadchunck', target=_loadchunck,args=(self.path, self.avilable_sets[self.train_pos]))
    p.start()
    self._preload = p
    
    super(CTRData, self).__init__()

##########################################################################################

class EpiData(BalancedData):
  def names2seq(self, names):
    sequences = []
    accum     = []
    seq_nrs   = set()
    for n,s in names:
      s = int(s)
      if s in seq_nrs:
        if len(accum)>0:
          sequences.append(accum)
        accum = []
        seq_nrs   = set()
      accum.append(n)
      seq_nrs.add(s)
  
    if s!=1:
      sequences.append(accum)
    return sequences

  def seq2names(self, sequences):
    names = []
    for s in sequences:
      names.extend(s)
    return names
    
  def __init__(self, path='/docs/entwicklung/data/epilepsy/', valid_size = 0.2, augment=0, split_no=0):
    f = file(path+'.names.pkl', 'r')
    names = cPickle.load(f)  # this contains [[name<str>, seq<str>],[...],...]
    f.close()
    f = file(path+'.data.pkl', 'r')
    data, label = cPickle.load(f)
    f.close()
    if valid_size == 0:
      self.train_d, self.train_l = data, label
      self.valid_d,  self.valid_l= np.zeros((0,0)), np.zeros((0,0))
    else:
      data = {n[0]: (d,l) for n,d,l in zip(names,data, label)}
      sequences = self.names2seq(names)
      rng = np.random.RandomState(22031991+split_no)
      rng.shuffle(sequences)
      s = int(len(sequences)  * valid_size)
      valid_names = self.seq2names(sequences[:s])
      train_names = self.seq2names(sequences[s:])
      self.valid_names = valid_names
      self.train_names = train_names

      self.valid_d = np.array([data[name][0] for name in valid_names ])
      self.train_d = np.array([data[name][0] for name in train_names ])
      self.valid_l = np.array([data[name][1] for name in valid_names ])
      self.train_l = np.array([data[name][1] for name in train_names ])

      self.train_d, self.train_l = self._augment(self.train_d, self.train_l, augment)
      self.valid_d,  self.valid_l = self._augment(self.valid_d,  self.valid_l, augment)
      print "Train prevalence: %.3f Valid prevalence: %.3f" %(self.train_l.mean(), self.valid_l.mean())

    super(EpiData, self).__init__()

  def swapSets(self):
    super(EpiData, self).swapSets()
    self.valid_names, self.train_names = self.train_names, self.valid_names
    self._split_done = False # because subsets must be also split

  def _augment(self, data, labels, factor, noise_level=0.02):
    if factor==1 or factor==0:
      return data, labels

    n = len(data)
    data_shape     = list(data.shape)
    data_shape[0]  = data_shape[0] * factor
    data_shape     = tuple(data_shape)
    result = np.zeros(data_shape, dtype='float32')
    new_l  = np.zeros((n*factor), dtype='int16')
    result[:n] = data
    for i in xrange(1,factor):
      result[i*n:(i+1)*n] = data + (self.rng.rand(*data.shape)-0.5)*noise_level
      new_l [i*n:(i+1)*n] = labels

    return result, new_l

##########################################################################################

class OttoData(BalancedData):
  conservative = [1,5,30,50,60,81,83,92]
  medium       = [1,3,5,6,9,11,17,20,21,27,28,30,48,50,51,60,64,78,81,83,92]
  aggressive    = [1,2,3,5,6,9,11,17,20,21,22,27,28,30,36,37,40,43,44,48,50,51,53,53,60,62,64,65,72,73,78,79,80,81,83,88,92]
  def __init__(self, path='/docs/entwicklung/data/product/data.pkl', valid_size=6000, split_no=1):
    with file(path, 'r') as f:
      data = cPickle.load(f)
      
    (d, l, self.test_d) = data
    d = d.astype(np.float32)
    l = l.astype(np.int16)
    super(OttoData, self).splitData(d, l, valid_size, split_no)
    super(OttoData, self).__init__()
    
  def selectFeatures(self, selection=None):
    if selection=='conservative':
      sel = self.conservative
    elif selection=='medium':
      sel = self.medium
    elif selection=='aggressive':
      sel = self.aggressive      
    else:
      assert selection is None
      return
      
    ix = np.ones(self.train_d.shape[1], dtype=np.int)
    sel = np.array(sel).astype(np.int)
    ix[sel] = 0
      
    
    self.train_d = self.train_d[:,np.flatnonzero(ix)]
    self.valid_d = self.valid_d[:,np.flatnonzero(ix)]
    self.test_d  = self.test_d[:,np.flatnonzero(ix)]


  def tf_idf(self):
    tfidf = feature_extraction.text.TfidfTransformer()
    self.train_d = tfidf.fit_transform(self.train_d).toarray().astype(np.float32)
    self.test_d  = tfidf.transform(self.test_d).toarray().astype(np.float32)
    self.valid_d = tfidf.transform(self.valid_d).toarray().astype(np.float32)

  def ica(self):    
    func = decomposition.FastICA(n_components=50, whiten=True)    
    self.train_d = func.fit_transform(self.train_d).astype(np.float32)
    self.test_d  = func.transform(self.test_d).astype(np.float32)
    self.valid_d = func.transform(self.valid_d).astype(np.float32)

  def pca(self):    
    func = decomposition.PCA(n_components=0.9, whiten=True)    
    self.train_d = func.fit_transform(self.train_d).astype(np.float32)
    self.test_d  = func.transform(self.test_d).astype(np.float32)
    self.valid_d = func.transform(self.valid_d).astype(np.float32)
    
  def normalise(self):
    m, s = self.train_d.mean(axis=0), self.train_d.std(axis=0), 
    self.train_d = (self.train_d/s - m).astype(np.float32)
    self.test_d  = (self.test_d/ s - m).astype(np.float32)
    self.valid_d = (self.valid_d/s - m).astype(np.float32)
    
  def normalisepos(self):
    M = self.train_d.max(axis=0)    
    self.train_d /= M
    self.test_d  /= M
    self.valid_d /= M

##########################################################################################

if __name__ == "__main__":   
  pass

