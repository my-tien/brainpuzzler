# -*- coding: utf-8 -*-
"""
Marius Felix Killinger --- Training MNIST
"""

### Paths and General ###
save_path        = "~/CNN_Training/MLP/" # (*) where to create the CNN directory. In this directory a new folder is created
save_name        = 'MNIST_MLP_warp'              # (*) with the save_name.
overwrite        = True                 # whether to delete/overwrite existing directory
plot_on          = True                 # [True]/False: whether to create plots of the errors etc.
print_status     = True                 # [True]/False: whether to print Training status to std.out
save_path += save_name+'/'
param_file       = None                 # string/None: optional parameter file to initialise weights from

### Data ###
data_path        = '/' # (*) Path to data dir
label_path       = '/' # (*) Path to label dir
# (*) list of tuples of file name and filed name in h5 data set
d_files          = []
# (*) list of tuples of file name and filed name in h5 data set
l_files          = []
n_lab            = None                # (*) <int>/None: (None means auto detect, very slow, don't do this!)
mode             = 'vect-scalar'           # combination of data and label types: 'img-img', 'img-scalar', vect-scalar'

### Gereral Data options ###
background_processes = True           # whether to "pre-fetch" batches in separate background process
label_prop_thresh    = None
data_class_name      = 'MNISTData'     # Name of Data Class in traindata module
data_load_kwargs     = dict(path='/docs/entwicklung/svn/Marius/Examples/mnist.pkl',
                            convert2image=False,
                            warp_on=True,
                            shift_augment=True)    # Arguments to init Data Class       
data_batch_kwargs    = dict()          # Arguments for getbach method of Data Class(for training set only!)
                                       # The batch_size is added internally and need not be specified here

### CNN Architecture ###
activation_func = 'tanh'               # string of list of strings: [tanh], abs, linear, sig, relu, single string or list with entry per layer
batch_size      = 50                    # (*) [1]/<int>  number of different slices used for one update step
dropout_rates   = 0.5                  # (*) list of <float>(0,1)/float: "fail"-rates per layer or globally.
                                       # The last layer has always no dropout. If list, length must be total number of layers
# Note: the last layer is added automatically (with n_lab outputs)
# Other
MLP_layers      = [800,800]                   # (*) list of <int>: numbers of filters for fully connected layers after conv layers


### Optimisation Options ###
n_steps               = 10**12          # (*) number of update steps
max_runtime           = 24 * 3600      # (*)  maximal Training time in seconds (overrides n_steps)
history_freq          = [2000]          # (*) create plots, print status and test model after x steps (must be list to be mutable)
monitor_batch_size    = 10000          # (*) number of patches to test model on (valid and Training subset)

weight_decay          = False          # ($) [False]/<float>: L2-norm on weights, False is equal to 0.0
class_weights         = None           # None or list/array of float weights for the classes, will be normalised internally
training_mode         = 'SGD'          # [SGD]/CG/RPORP/LBFGS optimiser method for training

LR_decay              = 0.998          # (*) decay of SGD learning rate w.r.t to an interval of 1000 update steps

# SGD
SGD_params      = dict(LR=0.03, momentum=0.9)  # (*) initial learning rate and momentum

# RPROP ($)
RPROP_params    = dict(penalty=0.35, gain=0.2, beta=0.7, initial_update_size=1e-4)
# CG ($)
CG_params       = dict(n_steps=4,       # update steps per same batch 3 <--> 6
                       alpha=0.35,      # termination criterion of line search, must be <= 0.35
                       beta=0.75,       # precision of line search,  imprecise 0.5 <--> 0.9 precise
                       max_step=0.02,   # similar to learning rate in SGD 0.1 <--> 0.001.
                       min_step=8e-5)

# LBFGS ($)
LBFGS_params    = dict(maxfun= 40,      # function evaluations
                       maxiter= 4,      # iterations
                       m= 10,           # maximum number of variable metric corrections
                       factr= 1e2,      # factor of machine precision as termination criterion (haha!)
                       pgtol= 1e-9,     # projected gradient tolerance
                       iprint= -1)      # set to 0 for direct printing of steps