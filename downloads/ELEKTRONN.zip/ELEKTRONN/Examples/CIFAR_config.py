# -*- coding: utf-8 -*-
"""
Marius Felix Killinger --- Training a Neural Network

CONFIGURATION FOR CNN-TRAINING
------------------------------

- In the comments values in [] denotes preferred/recommended settings
- Paths must have trailing '/'
- For isotropic CNNs (same input and filter size in all directions) the variable desired_input is scalar and
  filters & nof_filters are lists of scalars. For anisotropic CNNs all scalars are replaced by the
  lists of respective shapes.
"""

### Paths and General ###
save_path        = "~/CNN_Training/2D/" # (*) where to create the CNN directory. In this directory a new folder is created
save_name        = 'CIFAR-2'              # (*) with the save_name.
overwrite        = True                 # whether to delete/overwrite existing directory
plot_on          = True                 # [True]/False: whether to create plots of the errors etc.
print_status     = True                 # [True]/False: whether to print Training status to std.out
save_path += save_name+'/'
param_file       = None                 # string/None: optional parameter file to initialise weights from

### Data ###
data_path        = '/docs/entwicklung/data/CIFAR/' # (*) Path to data dir
label_path       = '/docs/entwicklung/data/CIFAR/' # (*) Path to label dir
d_files          = [('raw_w_%i.h5'%(i), 'raw') for i in xrange(1,6)] #, ('test_raw.h5', 'raw')]
l_files          = [('labels_%i.h5'%(i), 'labels') for i in xrange(1,6)]
del i
n_lab            = 10                # (*) <int>/None: (None means auto detect, very slow, don't do this!)
mode             = 'img-scalar'           # combination of data and label types: 'img-img', 'img-scalar', vect-scalar'

### Image Data Options (those are ignored for mode 'vect-scalar')###
valid_cubes      = [1]                  # List of cube indices (from the file-lists) to use as validation data,
                                       # may be empty

example_ignore_threshold = None         # If the fraction of negative labels in an example patch exceeds
                                       # this threshold this example is discarded
class_weights    = None               # None or list/array of float weights for the classes, will be normalised internally
grey_augment_channels = []            # (*) list of <int> channel-indices to apply grey augmentation, use [] to disable.
                                       # It distorts the histogram of the raw images (darker, lighter, more/less contrast)
flip_data        = True                # [True]/False: whether to flip/rotate/mirror data randomly (augmentation)
anisotropic_data = True               # (*) <Bool>, if True 2D slices are only cut in z-direction, otherwise all 3 alignments are used
warp_on          = False               # <Bool>/<Float> (0,1)Warping augmentations (CPU-intense, use background processes!)
                                       #  If this is a float than warping is applied to this fraction of examples e.g. 0.5 --> every other example
upright_x        = True
zchxy_order      = True               # set to True if data is in (z, (ch,) x, y) order, otherwise (ch, x, y, z) is assume
### Gereral Data options ###
background_processes = True           # whether to "pre-fetch" batches in separate background process

### CNN Architecture ###
activation_func = 'tanh'               # string of list of strings: [tanh], abs, linear, sig, relu, single string or list with entry per layer
batch_size      = 50                    # (*) [1]/<int>  number of different slices used for one update step
dropout_rates   = [0, 0.3, 0.4, 0.4, 0.4]                   # (*) list of <float>(0,1)/float: "fail"-rates per layer or globally.
                                       # The last layer has always no dropout. If list, length must be total number of layers
# Note: the last layer is added automatically (with n_lab outputs)
# Conv layers
n_dim           = 2                    # (*) 2/3, for non image data (mode 'vect-scalar') this is ignored
desired_input   = 31                  # (*) <int> or <2/3-tuple> in (x,y)/(x,y,z)-order for anisotropic CNN
filters         = [4, 2,  2,  2, ]                   # (*) list of <int>/[] or list of <2/3-tuples> in (x,y)/(x,y,z)-order
pool            = [2, 2,  2,  1, ]                   # (*) list of <int>/[],
nof_filters     = [50,60,100,100]                   # (*) list of <int>/[]
pooling_mode     = 'max'
MFP             = False                  # (*) list of <int{0,1}>/False: whether to apply Max-Fragment-Pooling in this layer
# Other
MLP_layers      = [200,200]                   # (*) list of <int>: numbers of filters for fully connected layers after conv layers

preview_data_path = None
preview_kwargs    = None # specification of preview data

### Optimisation Options ###
n_steps               = 10**12          # (*) number of update steps
max_runtime           = 24 * 3600      # (*)  maximal Training time in seconds (overrides n_steps)
history_freq          = [100]          # (*) create plots, print status and test model after x steps (must be list to be mutable)
monitor_batch_size    = 100              # (*) number of patches to test model on (valid and Training subset)

weight_decay          = 0.0005          # ($) [False]/<float>: L2-norm on weights, False is equal to 0.0
training_mode         = 'SGD'          # [SGD]/CG/RPORP/LBFGS optimiser method for training

LR_decay              = 0.993          # (*) decay of SGD learning rate w.r.t to an interval of 1000 update steps

# SGD
SGD_params      = dict(LR=0.02, momentum=0.9)  # (*) initial learning rate and momentum

# RPROP ($)
RPROP_params    = dict(penalty=0.35, gain=0.2, beta=0.7, initial_update_size=1e-4)
# CG ($)
CG_params       = dict(n_steps=4,       # update steps per same batch 3 <--> 6
                       alpha=0.35,      # termination criterion of line search, must be <= 0.35
                       beta=0.75,       # precision of line search,  imprecise 0.5 <--> 0.9 precise
                       max_step=0.02,   # similar to learning rate in SGD 0.1 <--> 0.001.
                       min_step=8e-5)

# LBFGS ($)
LBFGS_params    = dict(maxfun= 40,      # function evaluations
                       maxiter= 4,      # iterations
                       m= 10,           # maximum number of variable metric corrections
                       factr= 1e2,      # factor of machine precision as termination criterion (haha!)
                       pgtol= 1e-9,     # projected gradient tolerance
                       iprint= -1)      # set to 0 for direct printing of steps
