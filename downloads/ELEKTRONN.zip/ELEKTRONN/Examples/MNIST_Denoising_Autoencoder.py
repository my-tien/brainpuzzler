import sys, os
import matplotlib.pyplot as plt

if __package__ is None:
  sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__) ) ) )

from Training.traindata import MNISTData
from Net.convnet import MixedConvNN
from Net.introspection import embedMatricesInGray


# Load Data #
data = MNISTData(path='/docs/entwicklung/svn/Marius/Examples/mnist.pkl',convert2image=False, shift_augment=False)

# Create Autoencoder #
batch_size = 100
cnn = MixedConvNN((28**2),input_depth=None)
cnn.addPerceptronLayer( n_outputs = 300, activation_func="tanh")
cnn.addPerceptronLayer( n_outputs = 200, activation_func="tanh")
cnn.addPerceptronLayer( n_outputs = 50, activation_func="tanh")
cnn.addTiedAutoencoderChain(n_layers=None, activation_func="tanh",input_noise=0.3, add_layers_to_network=True)
cnn.compileOutputFunctions(target="regression")  #compiles the cnn.get_error function as well
cnn.setOptimizerParams(SGD={'LR': 5e-1, 'momentum': 0.9}, weight_decay=0)

print "training..."
for i in range(40000):    
    d, l = data.getbatch(batch_size)
    loss, loss_instance, _, time_per_step = cnn.trainingStep(d, d, mode="SGD")
   
    if i%100==0:
        print "update:",i,"; Training error:",loss

cnn.layers[3].input_noise.set_value(0.0)
loss, _, test_predictions = cnn.get_error(data.valid_d, data.valid_d)
cnn.layers[3].input_noise.set_value(0.3)
print "Test error:",loss
print "Done."



plt.figure(figsize=(14,6))
plt.subplot(121)
images = embedMatricesInGray(data.valid_d[:200].reshape((200,28,28)),1)
plt.imshow(images, interpolation='none', cmap='gray')
plt.title('Data')

plt.subplot(122)
recon = embedMatricesInGray(test_predictions[:200].reshape((200,28,28)),1)
plt.imshow(recon, interpolation='none', cmap='gray')
plt.title('Reconstruction')

d_v = data.valid_d
pred = test_predictions.clip(d_v.min(), d_v.max())
recon = embedMatricesInGray(pred[:200].reshape((200,28,28)),1)
plt.imshow(recon, interpolation='none', cmap='gray')


images = images.clip(d_v.min(), d_v.max())

images = embedMatricesInGray(test_predictions[:20].reshape((20,28,28)),1)