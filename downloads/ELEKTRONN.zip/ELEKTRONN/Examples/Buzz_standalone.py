import sys, os
import numpy as np

if __package__ is None:
  sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__) ) ) )

from Training.traindata import BuzzData
from Net.convnet import MixedConvNN


# Load Data #
target_scale = 999
data = BuzzData(path='/docs/entwicklung/data/Buzz/Twitter/twitter.pkl', target_scale=target_scale, fold_no=0)
# Create CNN #
batch_size = 100
cnn = MixedConvNN((11), input_depth=7, batch_size=None, recurrent=True) # depth <-> lenght of time series
cnn.addRecurrentLayer(30)
cnn.addPerceptronLayer(1, activation_func="linear")
cnn.compileOutputFunctions('regression')
cnn.setOptimizerParams(SGD={'LR': 1e-2, 'momentum': 0.9}, weight_decay=0)


print "training..."
for i in range(50000):  
    d, l = data.getbatch(batch_size)
    loss, loss_instance, param_var, time_per_step = cnn.trainingStep(d, l, mode="SGD")
    
    if i%1000==0:
        valid_error, valid_predictions = cnn.get_error(data.valid_d, data.valid_l[:,None])
        true_pred = (np.exp(valid_predictions) - 1)/target_scale
        true_lab  = (np.exp(data.valid_l[:,None]) - 1)/target_scale
        # target = np.log10(target*target_scale+1)
        print "update:",i,"; Validation MSE:",valid_error**2, "Validation error:",valid_error,"Training error:",loss
        
        
plt.scatter(true_lab, true_pred)
x = np.linspace(0,0.12,100)
plt.plot(x,x)        
print np.sqrt(((true_pred - true_lab)**2).mean())