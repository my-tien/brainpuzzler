.. _pipeline:

***************************
Using the Training Pipeline
***************************

This pages gives further details about the steps described in `the basic recipe <basic-recipe>`_.

.. contents::
   :local:
   :depth: 1

Principle of Working
====================

What happens after the configuration was set up and ``TrainCNN.py`` has been started:

	- The configuration file is parsed and some consitency checks are made. From the architecture parameters a :py:func:`Net.netutils.CNNCalculator` object is created.
	- A save directory is created, the *cwd* is set to this directory, a fully self-contained version of python and configuration files is created in a *Backup* folder in the save directory.
	- A :py:class:`Training.CNNData.CNNData` object is created. All CNN relevant architecture parameters (input size, offsets, strides etc.) are passed, such that suitable patches can be created. The data is read from disk.
	- The CNN is created and the training functions are compiled. Compilation of the gradient can take up to minutes the first time, but for subsequent runs, parts are cached and compilation becomes singificantly faster.
	- The training loop starts, in each iteration:
		* From the whole trainig set a batch is created by sampling random locations in the image files and "cutting" patches from these locations. The patches are augmented randomly according to the configuration.
		* The CNN makes one update step on the batch (or several steps for CG and lBFGS)
		* Every ``history_freq`` steps: the current performance is estimated on a larger number of patches (#TODO? also a sample image is predicted). Some numbers are printed, plots are made, and a history log is saved, too.
		* Every hour a backup of the CNN parameters/weights is performed

	- During this iteration you can use the `CNN console <console>`_ via ``ctrl+c``
	- After the maximal steps or maximal runtime was reached, everything is shutdown and the latest status is saved to files.



.. _data-format:

Data Format
===========

Transform yout data files to h5 data sets in separate files for images and labels.
	- images: shape (x,y,z)  or (channel,x,y,z), either ``float`` (0,1) or int (0,255)
	- labels: shape (x,y,z)
	- for classification: labels contains an integer numbers encoding the class membership, starting from 0, consequtively
	- for regression: labels contain float numbers

The z-axis is the the axis which has different units than x and y (e.g. different spatial resolution, or is time and not space).

.. Note::
	For 2d data you can stack the set of 2d images and labels to a cube each and train by iterating over the z-slices (then the option ``anisotropic_data`` must be set to ``True``).

.. Note::
	For *img-scalar* training labels the labels that correspond to a 3d cube are just a single number, and labels for a stack of 2d images (see note above) are a vector with an entry for every image.

Later in the configuration file **two** lists must be specified consisting of tuples of the form *(<file name>, <h5 data set name/key in that file>)*. One list for the images and one for the labels, both must have the **same** order.

The data types are preferably ``uint8`` which makes data loading fast. For the labels it pays off to use the compression option of h5. Note that in :py:class:`Training.CNNData.CNNData` the image data is internally converted to ``float32`` and the labels to ``int16`` for classificationa or ``float32`` for regression.

Offests for *img-img* Training
------------------------------

CNNs can only make predictions with offsets from the image border because the convoultion boundary mode is "valid" (the size of the offset can be calculated using :py:func:`Net.netutils.CNNCalculator`). This implies that for a given labelling extent the image data required is larger. So if possible, provide images that are larger than the labels by at least the offset, to make full use of you labelled data. Or conversly never label your data in the offset stripes!
The only important condition is that the labels and images must be symmetrically registered to their center. Then the images are cropped or the labels are 0-padded depending on the offset automatically. A 1d example: label.shape=(5) and image.shape=(7) ---> image[i+2] corresponds to label[i]; in particular image[3] corresponds to label[2], their centers.



.. _configuration:

Configuration of Parameters 
===========================

The default values for all configurable options are stored in ``Training/CNN_MASTER_CONF.py`` (where "all" means for this exemplary pipeline. The individual components e.g. the layers or the architecture of networks could be configured in many other ways, too!). Complementary there is a user file (exemplary ``Quick_config.py``, it sould be renamed for a new training). The user values override the default values. If an important user value is missing (e.g. the save directory) a warning is issued. The important parameters are marked with ! in the listing below.

The configuration file is basically a python file that contains assignments of values to variables.

This page only describes what the values do, for advice on how to find good settings refer to :ref:`training`.

The mode coloumn indicates if a parameter should be set by the user (!) or if this parameters is only needed in special cases and need not be configured ($). No indication means it can be left at default first, but tweaking might improve results. Default ``undefined`` means that there might be some value as default, but you should not assume that the value is being good for your situation.


Paths and General
-----------------

======================= =======	=========================== 	=============== ===========
Name			Mode	Type				Default		Explanation
======================= =======	=========================== 	=============== ===========
save_path		!	``string`` (trailing '/'!)	``undefined``	At this location a **new** directory with the name *save_name* created
save_name		!	``string``			``undefined``	The name of the save directory and the prefix for all created files
overwrite			``bool``			``True``	If set to ``False`` and the Training script is run for an existing directory, it terminates before overwriting any files
plot_on			$	``bool``			``True``	If ``True`` frequently plots of the training progress are created and saved to the save directory. As plotting is done in a sub-process it does not slow down training.
print_status		$	``bool``			``True``	If ``True`` freqently the several values (NLL, training error, validation error if available etc.) are printed in the python interpreter
param_file		$	``string``			``None``	Full path of parameter file. A new network can optionally be initialised with weights/parameters from the save file of another network.	
======================= =======	===========================	===============	===========


Data Basic
----------

======================= =======	========================== 	=============== ===========
Name			Mode	Type				Default		Explanation
======================= =======	========================== 	=============== ===========
data_path		!	``string`` (trailing '/'!)	``undefined``	Path to directory of training data files (raw images)
label_path		!	``string`` (trailing '/'!)	``undefined``	Path to directory of training label files
d_files			!	list of tuples			``undefined``	The data files to use from the directory. Tuples contain (<file name>(``string``), <h5 data set name/key in that file>(``string``)).
l_files			!	list of tuples			``undefined``	The label files to use from the directory. As above and in the same order!
n_lab			!	``int`` or ``None``		``undefined``	Number of labels i.e. different classes. If ``None`` this is detected automatically but that is slow.
mode				``string``			"img-img"       Mode of data and label types: img-img, img-scalar, vect-scalar, see also `here <training>`_.
======================= =======	========================== 	=============== ===========

Data Options
------------

Images
++++++

========================= 	=======	==============================	=============== ===========
Name			  	Mode	Type				Default		Explanation
========================= 	=======	============================== 	=============== ===========
cube_prios			  	``None`` or list of ``float``	``None``	List of SGD-sampling priorities for cubes (it must be in the same order as ``d_files``! ). The priorities are relative and need not be normalised. If ``None`` sampling probability ~ cube size
valid_cubes			  	list of ``int``			[]		List of cube indices (corresponding to ``d_files``) to use as validation data. May be empty, then validation performances are shown as ``nan``.
example_ignore_threshold 	$	``float``			0.0         	If the fraction of negative (i.e. unlabelled pixels) in an example patch exceeds this value the patch is discarded and a new patch is fetched. Only needed if there are negative / unlabelled labels at all.
grey_augment_channels	  	!	list of ``int``			[0]		Channel-indices to apply random grey value augmentation (GA) to. Use ``[]`` to disable. GA distorts the histogramme of the raw images (darker, lighter, more/less contrast).
flip_data				``bool``			``True``	Whether to randomly flip/rotate/mirror data for augmentation.
anisotropic_data	  	!	``bool``			``True``	If ``True`` 2D slices are only cut in z-direction, otherwise all 3 alignments are used.
lazy_labels		  	$	``bool``			``False``	``True`` activates special Training with lazy annotations (details :ref:`here <lazy-labels>`).
warp_on			  	!	``bool`` / ``float``		``False``	``True`` activates random warping deformations of training examples for augmentation. Alternatively a ``float`` (0,1) can be used to warp only a fraction of examples randomly. If this options is used background processes should be used at the same time.
zchxy_order				``bool``			``False``       Set to ``True`` if data is in (z, (ch,) x, y) order, otherwise (ch, x, y, z) is assumed. z first is slightly faster when loading data but for the actual training it is indifferent.
border_mode			!	``string``			"crop"		Only applicable for *img-scalar*. If the CNN does not allow the original size of the images the following options are available: "crop": cut the images to the next smaller valid input size, "0-pad" padd to the next bigger valid input with zeros, "c-pad" padd to the next bigger input with the average value of the border, "mirror" and "reject" which throws an exception.
========================= 	=======	==============================	=============== ===========

General
+++++++

========================= 	=======	============================== 	=============== ===========
Name			  	Mode	Type				Default		Explanation
========================= 	=======	============================== 	=============== ===========
background_processes	  	!	``bool``			``False``	Whether to "pre-fetch" batches in separate background process. This is advisable set to ``True`` in orderto speed up training, especially when warping is used. The whole training procedure may use up to 3 CPU cores then.
label_prop_thresh                       ``None`` or ``float`` (0.5,1)   ``None``	This threshold allows unsupervised label propagation (only for examples with negative/ignore labels).If the predictive probability of the most likely class exceeds the threshold, this class is assumed to be the correct label and the training is pushed in this direction. Should only be used with pre-trained networks, and values <= 0.5 are disabled. ``None`` disables this option.
========================= 	=======	============================== 	=============== ===========

.. warning::
	When unsing background proceeses, the main process should not be killed directly, but aborted using the CNN console via ``ctrl+c`` and ``kill`` or ``abort``, otherwise the subprocesses become zombies.

Alternative / *vect-scalar* Data Options
++++++++++++++++++++++++++++++++++++++

These replace the options from the image section

======================= =======	========================== 	=============== ===========
Name			Mode	Type				Default		Explanation
======================= =======	========================== 	=============== ===========
data_class_name      		``string``			``None``        Name of Data Class in TrainData
data_load_kwargs     		``dict``			``dict()``      Arguments to init Data Class
data_batch_kwargs    		``dict``			``dict()``      Arguments for getbach method of Class Data (e.g. special augmentations). The batch_size argument is added internally and needn't be specified here
======================= =======	========================== 	=============== ===========

CNN Architecture
----------------

General
+++++++

======================= =======	========================== 	=============== ===========
Name			Mode	Type				Default		Explanation
======================= =======	========================== 	=============== ===========
activation_func			``string`` or list therof	'tanh'		Global value or entry per layer. Possible values are: tanh, abs, linear, sig, relu. If list, length must be total number of layers
batch_size		!	``int``				1		Number of patches (i.e. training examples sliced from different locations in the training data) to use at one for an update step.
dropout_rates   		list of ``float`` (0,1)		``[]``          The "fail"-rates per layer or globally. Empty list diables dropout. The last layer has always no dropout. If list, length must be total number of layers
======================= =======	==========================	=============== ===========

Convolutional
+++++++++++++

======================= =======	======================= =============== ===========
Name			Mode	Type			Default		Explanation
======================= =======	======================= =============== ===========
n_dim			!	``int``			2		Spatial dimensionality of CNN (2 or 3). Channels of multi-channels input images (e.g. RGB) are not counted as a dimension as they are not spatial.
desired_input		!	``int`` or 2/3-tuple	200		Desired input size. This must be smaller than the size of the training images. If this is a scalar the size is used in all dimensions, if a tuple is uses each dimension has another size (only the z-dimension should be smaller for "flat" CNNs or anisotropic data). These sizes are not directly used but the next size that gives a valid architectures is automatically selected.
filters			!	see note 2		``undefined``	List of filter size in each layer
pool			!	see note 2		``undefined``	List of maxpooing factor for each layer
nof_filters		!	list of ``int``		``undefined``	List of number of filters for each layer
MFP			!	list of ``bool`` or 0/1	``undefined``	List whether to apply max fragment pooling for each layer. MFP is only intended for prediction, so for training all elements should be``0``.
======================= =======	======================= =============== ===========

.. note::
  The parameters ``filters`` and  ``pool`` can either be lists of ints or lists of 2/3-tuples of ints (scalar). For simple lists of ints the scalar values are used in all 2/3 CNN dimensions, for tuples each dimension has its own value.

Multi Layer Perceptron (MLP)
++++++++++++++++++++++++++++

======================= =======	======================= =============== ===========
Name			Mode	Type			Default		Explanation
======================= =======	======================= =============== ===========
MLP_layers              !       list of ``int``		``[]``          Numbers of neurons for fully connected layers after conv layers. Empty for img-img training and required for img-scalar training
======================= =======	======================= =============== ===========
	
.. note::
  The output layer is added automatically (with ``n_lab`` outputs). I.e. the total number of layers is ``len(nof_filters)+ len(MLP_layers) + 1`` (of course all lists here must have the same lenght, so it can be also ``len(filters)+1...``).





Optimisation Options
--------------------

======================= =======	============================== 	=============== ===========
Name			Mode	Type				Default		Explanation
======================= =======	============================== 	=============== ===========
n_steps			!	``int``				``undefined``	Number of maximal update steps
max_runtime		!	``int``				``undefined``	Maximal training time in seconds, may lead to termination before ``n_steps``. Measured is the total time including batch creation and performance estimates
history_freq		!	list of  1 ``int`` (!)		[2000]		Every ``history_freq`` training steps several values (NLL, training error, validation error if available etc.) are calculated and stored in an internal hisotry file. If the corresponding options are activated these values are also printed and plots are created. 
monitor_batch_size		``int``				10		Number of patches to test model for online performance estimation (on training set and if availbale on validation set)
dropout			$	``bool``			``False``       Activates Dropout in all layers except the last at a rate of 0.5
weight_decay          	$	``bool`` or ``float``		``False``       L2-penalty on weights with this weight relative to the gradient of the loss. ``False`` is equal to 0.0
class_weights			list of ``float``/``None``	``None``	Importance weights for the classes (must have lenght ``n_lab``), will be normalised internally. WEighting disabled by ``None``.
training_mode         		``string``			'SGD'           Select SGD/CG/RPORP/LBFGS as optimizer method for training
LR_decay              		``float``			0.993   	Decay multiplier for SGD learning rate w.r.t to an interval of 1000 update steps
======================= =======	==============================	=============== ===========

.. note::
	Regarding ``history_freq``:
	If the training or validation errors are estimated on many examples (``monitor_batch_size``) this might take a while, therefore if you plan to train for 24 hours you should not create an output every 10 seconds but rather every 30 minutes (values 2000 to 5000). But for debugging and checking if a new training case works it might be usefull to get several plots per minute (values 20 to 200) and use fewer monitor examples. If you know it works, you can raise the value online using the CNN console via ``ctrl+c``. Although this parameter is scalar it is a list for internal reasons.



Optimizer Hyperparameters
-------------------------

======================= =======	======================= =============== ===========
Name			Mode	Type			Default		Explanation
======================= =======	======================= =============== ===========
SGD_params		!	dict			see file	Initial learning rate and momentum for SGD
RPROP_params		$	dict			see file	see code
CG_params		$	dict			see file	see code	
LBFGS_params		$	dict			see file	see code and `here <http://docs.scipy.org/doc/scipy-0.15.1/reference/generated/scipy.optimize.fmin_l_bfgs_b.html>`_
======================= =======	======================= =============== ===========



Running TrainCNN
================

Once the parameter file is set up, the training script can be started. Run the script ``TrainCNN.py`` from command line ::

    python TrainCNN.py [config=</path/to_config_file>] [ gpu={Auto|False|<int>}] [no_X={True|False}]

or from an existing python interpreter (e.g. within spyder). We recommend ipython because it gives you completions for object attribute names when using the CNN commandline during training.

.. note::
   Using ``False`` as ``gpu`` arguments means a fallback to the configured device in ``.theanorc`` (which might be CPU). Otherwise it is advidsable give the number of of the target GPU directly as the automatic selection of a free GPU might not work for all drivers (it looks up the power state using nvidia-smi). If the system has only one GPU its number is 0.

.. note::
  When logging into a cluster via ssh an x-server for plotting might not be available. Matplotlib by default imports the interactive backend which would crash in this case. The option ``no_X`` can suppress this import by importing a backend at the very beginning that does not require an x-server.

.. _console:

CNN Command Line
================

During training various changes to the setup can be made using the console which is accessible via ``ctrl+c``::

	CNN MENU
	========

	    >> MNIST <<
	    Shortcuts:
	    'q' (leave interface),          'abort' (saving params),
	    'kill'(no saving),      	    'save'/'load' (opt:filename),
	    'sf'/' (show filters)',         'smooth' (smooth filters),
	    'sethist <int>',        	    'setlr <float>',
	    'setmom <float>' ,      	    'params' print info,
	    Change Training Optimizer :('SGD','CG', 'RPROP', 'LBFGS')
	    For EVERYTHING else enter your command in the command line


	>>> mfk@cnn: 

The follwing manipulations are possible:
	- Typing any of the above keywords (with optional arguments) + `Enter`
	- "Free" input without parenthesis is tranlsated to printing the value of the variable by that name, e.g.:
		>>> mfk@cnn: cnn.input_shape
                (50, 1, 26, 26)

        - "Free" input with parenthesis is tranlated to executing that command literally e.g.
		>>> mfk@cnn: cnn.setDropoutRates([0.5, 0.5, 0.5, 1.0])
 
        - If the return value of a function/method is to be printed, ``print`` must be added explicitly:
		>>> mfk@cnn: print cnn.SGD_LR.get_value()
		>>> 0.00995

	- Value assignments and variable instantiation are also possible
	- The command line resides within the scope of the trainig loop (``run`` method) of :py:class:`Training.trainer.Trainer` the and has access to:
		* The trainer object by ``self``
		* An instance of :py:func:`Net.convnet.MixedConvNN` by ``cnn``
		* An instance of :py:func:`Training.trainutils.ConfigObj` by ``config``
		* An instance of :py:func:`Training.CNNData.CNNData` by ``data``

The purpose of the command line is to allow the change of hyperparameters during training and to allow the inspection of the state of variables/parameters.

.. note::
	Some parameters cannot be changed or their change has no effect. This is mainly true for all properties that are hard-compiled into the theano functions like the network architecture (e.g. number of neurons per layer).


