Training package
================

Training.CNNData module
-----------------------

.. automodule:: Training.CNNData
    :members:
    :undoc-members:
    :show-inheritance:


Training.parallelisation module
-------------------------------

.. automodule:: Training.parallelisation
    :members:
    :undoc-members:
    :show-inheritance:

Training.trainer module
-----------------------

.. automodule:: Training.trainer
    :members:
    :undoc-members:
    :show-inheritance:

Training.trainutils module
--------------------------

.. automodule:: Training.trainutils
    :members:
    :undoc-members:
    :show-inheritance:

Training.warping_c module
-------------------------

.. automodule:: Training.warping_c
    :members:
    :undoc-members:
    :show-inheritance:

