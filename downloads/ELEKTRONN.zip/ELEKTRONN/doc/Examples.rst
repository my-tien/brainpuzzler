********
Examples
********

This page gives examples beyond using the "big" `pipeline <pipeline>`_. They examples are also intended to give an idea at which points furhter configurations custom network architectures could be realised.

.. contents::
   :local:
   :depth: 1

.. _mnist:

MNIST Example
=============

MNIST is a benchmark data set for digit recongition/classification. The data can be downloaded :download:`here <../Examples/mnist.pkl.gz>` and state of the art benchmarks can be found `here <http://yann.lecun.com/exdb/mnist/>`_.

Built-in + CNN
--------------

In the ``Examples`` folder is a file ``MNIST_CNN_config.py``, this is a configuration for *img-scalar* training and it uses a different data class than the "big" pipeline for neuro data. For such cases the options for data loading and batch creation are given given by keyword argument dictionaries::

	data_class_name      = 'MNISTData'     # Name of Data Class in traindata module
	data_load_kwargs     = dict(path='/docs/entwicklung/svn/Marius/Examples/mnist.pkl',
		                    convert2image=True,
		                    warp_on=True,
		                    shift_augment=True)    # Arguments to init Data Class       
	data_batch_kwargs    = dict()          # Arguments for getbach method of Data Class (for training set only!)
		                               # The batch_size is added internally and need not be specified here

The values in the file should alreday give a good result after about 15 minutes on a recent GPU, but you are invited to play around with the network architecture and hyperparameters
Remember to update the path to your mnist file!


Built-in + MLP
--------------

Same as above but with a *vect-scalar* config: ``MNIST_MLP_config.py`` for a plain MLP without convolutions. 


Standalone CNN
--------------

If you think the big pipeline and long configuration file is a bit of an overkill for MNIST we have an alternative standalone lightweight training loop in the file ``MNIST_CNN_standalone.py`` of the ``Examples`` folder. This example demonstrates what (in a slightly more elaborate way) happens under the hood of the big pipeline.
First we inport the required stuff and initialise a data loading Object from :py:mod:`Training.traindata`. It does not more than loading the trainig, validation and testing data and sample batches randomly - all further options e.g. for augmentation are not used here::

	import sys, os

	if __package__ is None: # because the modules lie in a "sibling" directory we add the path
	  sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__) ) ) )

	from Training.traindata import MNISTData
	from Net.convnet import MixedConvNN

	data = MNISTData(path='/docs/entwicklung/svn/Marius/Examples/mnist.pkl',convert2image=True, shift_augment=False)

Next we set up the Neural Network. All of the used methods of ``cnn`` have much more options which are explained in the API doc. If you want to create customised NNs you may start from a similar code and add a lot of keyword arguments... ::

	batch_size = 100
	cnn = MixedConvNN((28,28),input_depth=1)
	cnn.addConvLayer(10,5, pool_shape=2, activation_func="abs") # (nof, filtersize)
	cnn.addConvLayer(8, 5, pool_shape=2, activation_func="abs")
	cnn.addPerceptronLayer(100, activation_func="abs")
	cnn.addPerceptronLayer(80, activation_func="abs")
	cnn.addPerceptronLayer(10, activation_func="abs") # need 10 outputs as there are 10 classes in the data set
	cnn.compileOutputFunctions()
	cnn.setOptimizerParams(SGD={'LR': 1e-2, 'momentum': 0.9}, weight_decay=0)

Finally the training loop comes that makes weight updates in every iteration::

	for i in range(5000):  
	    d, l = data.getbatch(batch_size)
	    loss, loss_instance, time_per_step = cnn.trainingStep(d, l, mode="SGD")
	    
	    if i%100==0:
		valid_loss, valid_error, valid_predictions = cnn.get_error(data.valid_d, data.valid_l)
		print "update:",i,"; Validation loss:",valid_loss, "Validation error:",valid_error*100.,"%"


	loss, error, test_predictions = cnn.get_error(data.test_d, data.test_l)
	print "Test loss:",loss, "Test error:",error*100.,"%"

Of course the performance of this setup is not as good of the model above, but feel free tweak - how about dropout? Simply add ``enable_dropout=True`` to the cnn initialisation, all layers have by default a dropout rate of 0.5 unless it is suppressed with ``force_no_dropout=True`` when adding the layer. Don't forget to set the dropout rates to 0 while estimating the performance and to their old value afterwars, the methods ``cnn.setDropoutRates`` and ``cnn.setDropoutRates`` might be useful for that. Hint: for dropout another activation function and more neurons per layer and more iterations might be better...


Autoencoder Example
===================

This examples uses again MNIST data, but this time the target is not classification but compression. The input images have shape 28x28 but we will regard them as a 784 dimensional vector. The NNs shaped like a funnel: the number of neurons decreases from 784 input neurons to 50 internal neurons in the central layer. Then the number increases symmetrically to 784 for the output. The training target is to reproduce the input in the output layer (i.e. the labels are identical to the data). Because the inputs are float numbers, so is the output and this is a regression problem. The first part of the autoencoder compresses the information and the second part decompresses it. The weights of both parts are shared, i.e. each decompression layer has the transposed weight matrix of its corresponding compression layer as parameters and parameter updates are made simultaneously in both layers. For constructing an autoencoder the method ``cnn.addTiedAutoencoderChain`` is used. ::

	import sys, os
	import matplotlib.pyplot as plt

	if __package__ is None:
	  sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__) ) ) )

	from Training.traindata import MNISTData
	from Net.convnet import MixedConvNN
	from Net.introspection import embedMatricesInGray


	# Load Data #
	data = MNISTData(path='/docs/entwicklung/svn/Marius/Examples/mnist.pkl',convert2image=False, shift_augment=False)

	# Create Autoencoder #
	batch_size = 100
	cnn = MixedConvNN((28**2),input_depth=None)
	cnn.addPerceptronLayer( n_outputs = 300, activation_func="tanh")
	cnn.addPerceptronLayer( n_outputs = 200, activation_func="tanh")
	cnn.addPerceptronLayer( n_outputs = 50, activation_func="tanh")
	cnn.addTiedAutoencoderChain(n_layers=None, activation_func="tanh",input_noise=0.3, add_layers_to_network=True)
	cnn.compileOutputFunctions(target="regression")  #compiles the cnn.get_error function as well
	cnn.setOptimizerParams(SGD={'LR': 5e-1, 'momentum': 0.9}, weight_decay=0)

	print "training..."
	for i in range(10000):    
	    d, l = data.getbatch(batch_size)
	    loss, loss_instance, time_per_step = cnn.trainingStep(d, d, mode="SGD")
	   
	    if i%100==0:
		print "update:",i,"; Training error:",loss

	loss,  test_predictions = cnn.get_error(data.valid_d, data.valid_d)
	print "Test error:",loss
	print "Done."

	plt.figure(figsize=(14,6))
	plt.subplot(121)
	images = embedMatricesInGray(data.valid_d[:200].reshape((200,28,28)),1)
	plt.imshow(images, interpolation='none', cmap='gray')
	plt.title('Data')
	plt.subplot(122)
	recon = embedMatricesInGray(test_predictions[:200].reshape((200,28,28)),1)
	plt.imshow(recon, interpolation='none', cmap='gray')
	plt.title('Reconstruction')



RNN Example
===========

TODO
