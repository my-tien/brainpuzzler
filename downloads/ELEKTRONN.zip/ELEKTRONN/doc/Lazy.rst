.. _lazy-labels:

***********
Lazy Labels
***********

Motivation
----------

For *img-img* training tasks (e.g. segmentation or pixelwise object detection) one factor limiting the quality of CNN training and usability is the requirement of large expensive ground truth: a volume equally large as the raw image has to be annotated pixelwise by humand expert, similar to painting with an image manuipulation program. Naturally, this can only be done for a small number of image cubes and is therefore not likely to cover the full variety of possible input data. Many benchmarks are performed with respect to such data sets but for actual applications this might not be sufficient to solve the task. For example in EM neuro images of larger brain sections, a diversity of distinct regions is present which are so large and rather "monotonic" that they are usually not considered for training data, because labelling them would be expensive compared to the gained information. Such areas are e.g. myelinated axons or cell nuclei. But it may occour that CNN predictions go wrong in particular in those areas, because they were never presented to the CNN during training and certain structures resemble target objects (e.g. vesicle clouds) and give rise to false positives. Therefore, in real applications, it is important to include those "monotonic" areas into the trainig set.

Solution
--------

Lazy Labels refers to groundtruth that can be generated with very little effort and gives the possibility to include monotnic image examples into the training set. An example use case is a EM volume patch of a cell nucleus, background class ``0``, but the patch contains also mitochondria, class ``1``, (or more categories of other objects) but certainly no vesicle clouds, class ``2``. The cheapest option is to not label anyhting at all in this cube and instead specify *masks* that tell all classes that have not been labelled *and* masks that tell that there are no instances of class ``2`` in this patch whatsoever. During training this patch only contributes to the loss if the CNN predicts class ``2`` and this prediction is driven towards zero probability on this patch. This provdides of course much less training information and therefore it would be suitable to use this patch less frequent by giving it a low value in ``cube_prios`` compared to densely labelled cubes.
The other option is to label the cell nuculeus manually as background (because it is large contiguous object that is relatively cheap and it needn't even be exactly to the border) and set a mask that the background was labelled. For the volume around the nucleus the labels are set to ``-1`` to be ignored (this area would be more expensive to label because there might be many small objects of different classes e.g. mitochondria). Thus the information content is slightly higher than for the first option.

In any case this can only be used to complement densely labelled data.


Application
-----------

The exact effect of the masks is precisely described in the API documentaiton of the loss function (:py:meth:`Net.convlayer2d.ConvLayer2d.NLL` and :py:meth:`Net.convlayer3d.ConvLayer3d.NLL`).

To use lazy labels 2 things must be done:
	1. Turn the option ``lazy_labels`` in the configuration
	2. For every image/label cube pair: add another h5 dataset in the **same** h5 file of the labels by the data set name "info". This data set must be a tuple containing two arrays of lenght ``n_lab`` with entries 0 or 1. The first array gives ``mask_class_labeled`` corresponding to this volume, the second ``mask_class_not_present``.
	3. (optionally) set lower ``cube_prios`` for the cubes with less label information content.
