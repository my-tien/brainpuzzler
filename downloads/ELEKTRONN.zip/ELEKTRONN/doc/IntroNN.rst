.. _training:

*****************************************
Practical Introduction to Neural Networks
*****************************************

.. contents::
   :local:
   :depth: 2

General
=======

Neural Networks (NNs), including CNNs as a special case, are (from the point of view of this software toolkit) a class of non-linear, parametrised functions that maps :math:`\mathbb{R}^N \rightarrow \mathbb{R}^M`. For a more comprehensive description refer to `Marius' Intro <?>`_.

NNs are models for supervised training. This means the user must provide input *examples* and corresponding desired outputs. Together they form a *trainig set*. The parameters (also called synapse *weights*) are optimised by gradient descent techniques in order to minimise the deviation of the current NN output from the desired output. The deviation between current output and desired output is called *loss*. Provided the training was configured well and the training data covers a representative variety of input data, the NN *generalises* i.e. it is able to produce good output *predictions* for unseen input data. The accuracy on a hold out *validation* data set gives an estimate of the generalisation capability and detects overfitting. 

NNs can outperform many other models but they are rather fastidious enteties: if you don't give them what they want you get nothing back. In particular they demand many training examples and labels with as little noise as possible, furthermore they might require a high number of trial runs with different architectures and hyperparameters until a good model is found. In short, this means they are ressource intensitive. The reward is the prospect of amazing results, but that requires some effort and might not work out of the box.



Trainig Modes
=============

Generally there are three *modes* of training set ups:
	- **img-img**: input data **and** output data are image like (i.e. there exist neigbourhood relations between adjacent elements in the data arrays. This property is irrespective of dimension and might be generalised to neigbourhoods of temporary nature or other). E.g. for membrane segmentation the labels are like images that have ``1`` for pixles in which a membrane is present in the image and ``0`` for background.

	- **img-scalar**: the input data is image like, but the labels correspond the the image as a whole - not to pixels/locations. E.g. "this image shows a dog" or "this is an image of digit 3"

	- **vect-scalar**: the input data is a vector of arbitrary features (i.e. there exists no special relation between adjacent elements in the vector). This could also be a flattened image as in the `MNIST-example <mnist>`_, but more illustrative are e.g. demographic properties of persons or word counts of a document.

Convolutions are only applicable for the first and second mode. Note that a neighbourhood relation can also be temporary e.g. in a stack of 2d images (x,y-axes) from a video sequence the pictures next to each other (z-axis) are close regarding their time and a convolution along the z-axis makes sense (*spatio-temporal filter*).

The tutorial for the `trainig pipeline <pipeline>`_ assumes the operation mode *img-img*. *img-scalar* training is mentioned in comments and vect-scalar is explained in the `MNIST-example <mnist>`_.


Data Consideratons
==================


Label Quality
-------------

Training data must in general be densly labelled i.e. for each pixel in the raw training data the corresponding label pixel must contain the class index (or a real value for regression). That means e.g. for object detection/classification all pixels of that object must carry the index of the class to which the object belongs. Obviously noise in these annotataions is bad (e.g. the labelled volume of the object is smaller or larger than the real object extent). If you can influence the labelling stage make sure that annotators do not make "safety-margins" around object (or even make annotations next to the object). If the labelling is already done and you are unhappy with your training result, you can try to modify the labels by dilation or erosion. For very easy tasks the results could still be good since the CNN might learn what the annotator "actually meant".

The above is not applicable for *img-scalar* training.


Label Coverage
--------------

Obtaining dense labels is expensive. However, the training quality can improve a lot as the training data covers greater ranges of possible inputs. A CNN cannot make good predictions for data it has never seen. As a compromise ELEKTRONN has special loss function that allows training on data that is not densely labelled in the above sense. This trainig mode still requires some dense examples (to get the learning kicked off in the right direction) and additionally you can provide data that is very cheap to annotate. For details see lazy-labels_.

Another way to make good use of labelling ressources is to know the fact that a given labelled region actually refers to an image region that is larger (see :ref:`data-format`): never label your data in the offset stripe!

The above is not applicable for *img-scalar* training.


Network Architecture
====================

When defining an architecture several things should be considered:

Convolutional
-------------

	* Maxpooling:
		- Reduces the feature map size of that layer, so subsequent layers are cheaper to compute.
		- And adds some translational invariance (e.g. it does not matter if the edge is a little bit more right or left). This is good to some extent, but too many consecutive poolings reduce localisation.
		- Increases the field of view of a single output neuron.
		- Results in *strided* output/predictions due to the downsampling. For a given number of input neurons the number of output neurons is reduces by the pooling factor, this is important because too few output neurons give noisier gradients and the training progress might be slower. Another effect is that poolings make prediction more expensive. The simple and slow way is iterating over all positions between the strides and accumulate the strided predictions to a dense image. The fast (and computationally optimal) way is to activate :ref:`mfp` which gives dense images directly but requires a lot of GPU-RAM.
		- The strides in each dimension is the product of pooling factors in each dimension (e.g. 2**4=16), the number of total prediction positions (or fragments for MFP) is the product of all pooling factors: in 3d 4 poolings in all dimensions gives the unreasonable number 4096! As mentioned for the filter sizes below, it is possible to create "flat" 3d CNNs that avoid this, by applying the pooling only in x and y with factors (2,2,1).
		- It is recommended to use only poolings in the first layers and not more than in 4 layers in total. The value of the pooling factor should 2 be.

	* Filter sizes:
		- Larger filters increase the field of view.
		- Larger filters are slower to compute but do not require significantly more GPU-RAM.
		- Larger filters introduce more model parameters, but as the number of filters that can be used is limited by speed or GPU-RAM the greater "expressivity" of larger filters might actually not be utilised and smaller filters can be equally good and faster or even better.
		- In the very first layer the filter size must be even if pooling by factor 2 is used. Otherwise output neurons lie "between" input pixels.
		- Filter sizes and pooling factors can defined for each dimension separately. This is usefull if 3d data has anisotropic resolution or "just a little" information in the z-direction is needed. A usefull and fast compromise between a plain 3d and 2d network is CNN that has e.g. filter shape (4,4,1) in the first layers and later (2,2,2): this means the first part is basically a stack of parallel 2d CNNs which are later concatenated to 3d CNN. Such "flat" 3d CNNs are faster than their isotropic counterparts.
		- The last layers may have filter sizes (1,1,1) which means no convolution in any dimension and is eqivalent to a stack of parallel fully connected layers (where the number of filters corresponds to the neuron count).

	* Number of Filters:
		- Due to larger feature map sizes in the first layers (before pooling) less filters can be used than in later layers.
		- A large number of filters in later layes may be cheap to compute for training as the feature map sizes are small but predictions becomes expensive then.
		- Still it is advisable to have a tendency of increasing filter size for later layers. This can be motivated from the view, that early layers extract primitves (such as edges) and the number of relevant primitves is rather small compared to the number of relevant combinations of such primitves)

	* To get centered field of views (this means label pixels are aligned with output neurons and do not lie "in between") when using pooling factors of 2, the filter size in the first layer must be even.


Multi Layer Perceptron (MLP)
----------------------------

	* MLP layers (Perceptron layers): these are only needed for *img-scalar* training. The image-like feature maps of the last convolutional layer are flatted to a vector and given as input to the perceptron layer, thus one or more perceptron layers can be attached. If the image-like extent of the last convolutional layer is large and/or the layer has many filters the flattened vector might be quite long, it is therefore advidsable to reduce the image extend by using maxpooling in the layers to a small range, e.g. 2x2(x2). The convolutional part can be interpreted as a feature extractor and perceptron layers as a classificator, but in fact this is rather a continuous transition. Each MLP layer is characterised by the number of (output) neurons.

.. Note::
 Always check the CNN architecture before starting a training by by using :py:func:`Net.netutils.CNNCalculator`. Only the input shapes in the attribute ``valid_inputs`` returned can be used. This is also applicable for *img-scalar* training, because for pooling, the layers must have even sizes; if the desired architecture is not possible for the size of the images, the images must be constant-padded/cropped to change their size or the architecture must be changed.


Bearing the above in mind, in the end the particular data set has the last say and various architecture versions should be tested against each other to find out what works well.


Tweaks
======

Class weights
-------------

Often data sets are unbalanced (e.g. there are more background pixels than object pixels). In such cases the classifier might get stuck predicting the most frequent class with high probability and assigning little probability to the remaining classes. Using class weights, the training errors (i.e. the incentives for the classifier to adapt to the data) can be changed to give the less frequent classes greater importance. This prevents the mentioned problem.

Data Augmentation
-----------------

CNNs are well performing classifiers, but require a lot of data examples to generalise well. A method to face this demand is data *augmentation*, which means from the finite given data set (potentially infinitly) more examples are created by applying transforms under which the labels are expected to be constant. This is especially well suited for images: practically allways small translations and changes in brightness and contrast leave the overall content intact. In many cases rotations, mirroring, little scaling and minor warping deformations are possible, too. All mentioned methods are implemented in the :ref:`pipeline <pipeline>` for images. For *img-img* training the labels are subjected to the geometric transformations jointly with the images. By applying the transformations with randomly drawn parameters the training set is practially infinitely large. It should however be noted, that the warping deformations require on average greater patch sizes (internally only, the user specification is the same!) and thus the border regions are exposed to the classifier less frequent. This can be migitated by applying the warps only to a fraction of the example. Further should be noted that the training set is not truly infinitely large, because the obtained examples are highly correlated compared to genuinely more data.


Dropout
-------

Dropout is a major regularisation technique for Neural Networks that improves generalisation. When using dropout for training, a fraction of neurons are turned off - but randomly, changing every new training iteration step. This can be interpreted as training an *ensemble* of networks (in which the members share common weights) and sampling members at random every training step. For predicting, the ensemble average is the desired quantity which can be approximated by turning all neurons on (because then the average incomming activations are larger, the weights are rescaled before doing that). Training with dropout requires more neurons per layer (i.e. more filters for CNNs), larger training times and larger learning rates. It is advisable to first narrow down a usefull architecture without dropout and from that point start experimenting with dropout.

Weight Decay
------------

Weight decay is synonymous with a L2 penalty on the weights. This means additional to the loss that comes from the deviation of current output and desired output, large weight values are regarded as loss - the weights are driven to have smaller magnitudes while at the same time being able to produce good output. This acts as a regulariser.

Input Noise
-----------

In contrast to Dropout this source of randomisation adds Gaussian noise to the input data of a layer (usually the very first layer). Thereby the NN is forced to be invariant and robust against small differences in the input and to generalise better. This is a way of data augmentation that happens in the NN itself.




Training / Optimisation
=======================

Because of the non-linear activation functions the loss of an NNs is a highly non-convex function of its weights. For optimisation only gradient descent techniques with different heuristics are applicaple. Convergence is a user-defined state, either determined by good enough results (or no progress possible any more) or by the point where the loss on a held out *validation set* beginns to increase, while the loss on the training set still decreases - continuing training in this situation inevitably leads to overfitting and bad generalisation.


Stochastic Gradient Descent (SGD)
---------------------------------

This is the basic principle of all other optimisers. SGD is the most common optimisation scheeme and works in most cases. One advantage of SGD is that it works well with only one example in the batch.

In every interation:
	- From the training data one or several examples are drawn. The number of drawn examples is called *batch size*.
	
	- The output of the NN, given the current weights, is calcluated

	- The **gradient** of the loss (deviation between output and desired output) is calculated w.r.t to the weights
	- The weights are *updated* by following down the gradient for a fixed step size - the *learning rate*
	- The whole procedure is repeated with a new sample of data until convergence

For the learning rate, usually a schedule to drecrease it by a fixed fraction every N iterations is applied.

Momentum
++++++++

Momentum replaces the immediate gradient by an exponential moving average over the previous gradients. This can speed up progress by accumulation of gradient magnitude and prevent overfitting to only the current example by averaging over other examples. Momentum is parametrised by a hyperparameter that determines the mixing rate of the previous gradients and the current gradient.



RPROP
-----

RPROP is a heuristic that determines the learning rate for every parameter individually based on the criterion how often the sign of the graident changes. If the sign stays the same for a long time the learning rate grows (similar to momentum) and if the sign fluctuates a lot very small steps are made for this parameter.
RPROP can be very fast but tends to be too aggressive for some data sets leaving a larger sprad between training loss and validation loss.


Conjugate Gradient (CG)
-----------------------

Conjugate gradient uses a heuristic to estimate the value of the momentum hyperparameter. In addition the learning rate is not fixed but the optimal step size is found by a bounded line search along the gradient direction. CG requires to do multiple steps on the same batch for the heuristic to work.

CG need less iteration steps but is slower per step. Larger batch sizes are needed because several steps are done per same batch. Generalisation properties can be superior to SGD and it can even be faster but that depends on the particular data set and the tuning of hyperparameters.


l-BFGS
------

This method aims at estimating the inverse Hessian from the history of gradients. Similar to CG this history must be aquired on the same batch and the number of steps on the same batch is even higher. Using the approximate inverse Hessian parameter updates can be made with a second order correction (plain gradient descent is a linear approximation). Again batch sizes must be larger because of the high number of steps per same batch.


Tipps for Tuning
================

The learning rate should be as large as possible at the beginning of the training and decrease gradually. Conversely the momentum should be raised towards the end of the training but it can also be keept constant.
As large as possible for the learning rate means the follwing: since the gradient is only a linear approximation the loss decreases just along a small invervall on the gradient and for larger steps the function rises (very quickly). Thus by setting a fixed learning rate, some update steps may in fact lead to an increase of the loss if they are to large. The learning rate should be so large that **most** of the updates decrease the loss but some lead to increase.

The learning rate depends on the NN architecture and the batch size. Deeper nets commonly require smaller leraning rates. Larger batches can go with larger learning rates.



