*********************************
Tips for Adaptation and Extending
*********************************

General
-------

Many customisations can be achieved by sub-classing objects from the :py:mod:`Training` package or adding new functions in the layers, e.g.:
	- If you wish to create another network architecture or use layer options which are not configurable through the config file (e.g. input noise or weight sharing between layers) you can still use the pipeline but make a sub-class of :py:class:`Training.trainer.Trainer` in which the ``createNet`` method is overridden by your own code. Then you must only make sure in the script ``TrainCNN.py`` that your own Trainer class is used.
	- If you wish another weight initalisation you can override the ``randomizeWeights`` methods in the layer classes (e.g. there is already a ansatz for initialising the 2dconvlayer with gabor filters)


Watch Outs
----------

	- In the training pipeline, it is not possible to have all imports at the top of the file because some imports can only be made after some conditions are fulfilled (e.g. before any theano imports the device must be initialised - otherwise the value from ``.theanorc`` is used and that cannot be changed later)
	- When adding new configuration options to the pipeline, you must also put them into ``Training/CNN_MASTER_CONF.py`` otherwise they will be considered as invalid/non-existend parameters.
	- For 3d data the internal order is (z,x,y), but filter shapes etc. are externally still defined as (x,y,z) and swapped internally. The full internal processing order for 3d convolutions is (batch, z, channel, x, y).

