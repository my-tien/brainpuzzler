# -*- coding: utf-8 -*-
"""
ELEKTRONN - Neural Network Toolkit
Copyright (c) 2015 Gregor Urban, Marius Killinger

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software for non-commercial purposes, including
the rights to use, copy, modify, merge, publish, distribute, the Software,
and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The Software shall neither be used as part or facilitating factor of military
applications, nor be used to develop or facilitate the development
of military applications.
The Software and derivative work is not used commercially.
The above copyright notice and this permission notice shall be included in
all copies and all derivative work of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

import sys, os, inspect, socket

hostname = socket.gethostname()
# prevent Qt-backend on remote machines early! (other modules may import mpl)
no_X = False
for arg in sys.argv:
  if 'no_X=' in arg:
    arg = arg.strip('no_X=')
    if (arg=='True' or arg=='true'):
       no_X = True
    
# Insert Names of hosts that don't have x-server running
if hostname in ['synapse01', 'synapse02', 'synapse03', 'synapse04', 'tesla'] or no_X:
  print "Importing Matplotlib without interactive backend, plots can only be saved to files in this session!"
  import matplotlib
  matplotlib.use('AGG')

from Training import trainutils # contains import of mpl
#from Evaluation import evaluate

#config_file      = "Examples/Buzz_config.py"
config_file      = "Examples/MNIST_CNN_config.py"
#config_file      = "Examples/MNIST_MLP_config.py"
#config_file      = "Examples/Piano_config.py"
#config_file      = "Examples/CIFAR_config.py"
#config_file      = "Examples/Adult_config.py"
#config_file      = "Examples/DRIVE_config.py"
#config_file      = "Relu_comp_warp.py"
#config_file      = "DRIVE_config.py"
gpu              = None # int specifying id of GPU to initialise for usage. E.g. 1 --> "gpu1", None will
                        # initialise gpu0, False will not initialise any GPU. This only works if "device" is
                        # not set in ``.theanorc``. If the initialisation fails an error will be printed but
                        # the script will not crash.
this_file        = os.path.abspath(inspect.getframeinfo(inspect.currentframe()).filename)
# commandline arguments override config_file and gpu if given as argv
config_file, gpu = trainutils.parseargs(sys.argv, config_file, gpu)
# copies scripts, sets gpu (theano import)
config           = trainutils.ConfigObj(config_file, gpu, this_file)
from Training import trainer # contains import of theano
os.chdir(config.save_path) # The trainer works directly in the save dir

### Main Part ################################################################################################
if __name__=="__main__":
    T = trainer.Trainer(config)
    T.loadData()
#    if 'DRIVE' in config_file:
#      print "DRIVE Fixes"
#      # only green channel
#      x = T.data.train_d[0]
#      T.data.train_d[0] = x[:,1:2]
#      T.data.n_ch = 1
      
    T.createNet()
    T.run()
#    evaluate(T.cnn, color='hsv', test_nll=0, name='train-15', thresh_i=None, source='train',
#             rec=False, data_path='/home/mkilling/data/DRIVE/')
#
#    T.run()
#    evaluate(T.cnn, color='hsv', test_nll=0, name='train-30', thresh_i=None, source='train',
#             rec=False, data_path='/home/mkilling/data/DRIVE/')    
